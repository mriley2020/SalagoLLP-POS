<div class="card card-form">
    <div class="card-body">
        <h4 class="card-title">{{ __('trans.basic_info') }}</h4>
        <p class="card-title-desc">{{ __('trans.fill_info_below') }}</p>
        <div class="row">
            <div class="col-sm-6">
                <div class="form-group product-input" style="position:relative;">
                    <label for="product-name">{{ __('trans.product_name') }}</label>
                    <small class="@error('product_name') is-invalid @enderror">{{ strlen(@$old['product_name']) }} / 100</small>
                    <input id="product-name" name="product_name" maxlength="100" type="text" class="form-control @error('product_name') is-invalid @enderror" value="{{ @$old['product_name'] }}">
                    @error('product_name') <span class="error">{{ $message }}</span> @enderror
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="stock">{{ __('trans.stock') }}</label>
                    <input id="stock" name="stock" type="text" class="form-control @error('stock') is-invalid @enderror" value="{{ @$old['stock'] }}">
                    @error('stock') <span class="error">{{ $message }}</span> @enderror
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label class="control-label">{{ __('trans.category') }}</label>
                    <select class="form-control select2 @error('category') is-invalid @enderror" name="category">
                        <option value="">{{ __('trans.select_option') }}</option>
                        @foreach($category_list as $category)
                            <option @if(@$old['category'] == $category->id) selected @endif value="{{ $category->id }}">{{ $category->name }}</option>
                        @endforeach
                    </select>
                    @error('category') <span class="error">{{ $message }}</span> @enderror
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="purchase-price">{{ __('trans.purchase_price') }}</label>
                    <input id="purchase-price" name="price" step="any" type="text" class="form-control @error('price') is-invalid> @enderror" value="{{ @$old['price'] }}">
                    @error('price') <span class="error">{{ $message }}</span> @enderror
                </div>
            </div>
        </div>
        <div class="row">

            <div class="col-sm-6">
                <div class="form-group">
                    <label for="sale-price">{{ __('trans.sale_price') }}</label>
                    <input id="sale-price" name="sale_price" step="any" type="text" class="form-control @error('sale_price') is-invalid @enderror" value="{{ @$old['sale_price'] }}">
                    @error('sale_price') <span class="error">{{ $message }}</span> @enderror
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="form-group">
                    <label for="product-desc">{{ __('trans.product_desc') }}</label>
                    <textarea name="product_description" maxlength="3000" class="form-control @error('product_description') is-invalid @enderror" id="product-desc" rows="5">{{ @$old['product_description'] }}</textarea>
                    <small class="float-right">{{ strlen(@$old['product_description']) }} / 3000</small>
                    @error('product_description') <span class="error">{{ $message }}</span> @enderror
                </div>
            </div>
        </div>
    </div>
</div>
