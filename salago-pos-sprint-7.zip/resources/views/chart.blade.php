@extends('layouts.main-layout')
    <?php $use = ['datatable']; ?>
    
    @section('customStyle')
    
    @endsection
    
    @section('content')
        <div class="page-content">
            <div class="container-fluid">

              
               <canvas id="myChart"></canvas>

            </div> <!-- container-fluid -->
        </div>
    @endsection

    @section('customScript')
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
          <script>
var ctx = document.getElementById('myChart').getContext('2d');
var chart = new Chart(ctx, {
    // The type of chart to create
    type: 'bar',

    // The data for the dataset
    data: {
        labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July','August','September','November','December'],
        datasets: [{
            label: 'Sale Graph',
            backgroundColor: 'rgb(255, 99, 132)',
            borderColor: 'rgb(255, 99, 132)',
            data: [
                {{ $count['jan'] }},
                {{ $count['feb'] }},
                {{ $count['mar'] }},
                {{ $count['apr'] }},
                {{ $count['may'] }},
                {{ $count['jun'] }},
                {{ $count['jul'] }},
                {{ $count['aug'] }},
                {{ $count['sep'] }},
                {{ $count['oct'] }},
                {{ $count['nov'] }},
                {{ $count['dec'] }}
            ]
        }]
    },

    // Configuration options go here
    options: {}
});




</script>
  
    @endsection
