<?php if (isset($component)) { $__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MainLayout::class, ['title' => ''.e(__('trans.orders_listing')).'','use' => ['datatable']]); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('content'); ?> 
        <div class="page-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-flex align-items-center justify-content-between">
                            <h4 class="mb-0 font-size-18">Orders Listing</h4>

                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                                    <li class="breadcrumb-item active">Order Listing</li>
                                </ol>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row mb-4">
                                    <div class="col-sm-4">
                                        <h4 class="card-title">Order Listing</h4>
                                    </div>
                                    <div class="col-sm-8">
                                        <div class="text-sm-end text-right">
                                            <a href="<?php echo e(route('order.create')); ?>" class="btn btn-primary ">Add Order</a>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <table id="orders-datatable" class="table table-bordered dt-responsive  nowrap w-100">
                                    <thead>
                                        <tr>
                                            <th>Invoice ID</th>
                                            <th>Customer Name</th>
                                            <th>Order Date</th>
                                            <th>Total</th>
                                            <th>Paid</th>
                                            <th>Due</th>
                                            <th>Payment Type</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div> 
                </div>
            </div>
        </div>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('customScript'); ?> 
        <script>
            const table = $("#orders-datatable").DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    type: "POST",
                    data:{
                        _token: "<?php echo e(csrf_token()); ?>"
                    },
                    url: "<?php echo e(route('order.get')); ?>"
                },
                columns: [
                    { data: "id" },
                    { data: "customer_name" },
                    { data: "order_date" },
                    { data: "total" },
                    { data: "paid" },
                    { data: "due" },
                    { data: "payment_type" },
                    { data: "action" }
                ]
            });
        </script>
     <?php $__env->endSlot(); ?>

 <?php if (isset($__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d)): ?>
<?php $component = $__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d; ?>
<?php unset($__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH E:\XAMPP\htdocs\salagoposupgraded\resources\views/orders-listing.blade.php ENDPATH**/ ?>