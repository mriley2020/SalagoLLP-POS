<?php $__env->startSection('title',__('trans.orders_listing')); ?>

<?php $use = ['datatable']; ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0 font-size-18">Orders Listing</h4>

                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                                <li class="breadcrumb-item active">Order Listing</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row mb-4">
                                <div class="col-sm-4">
                                    <h4 class="card-title">Order Listing</h4>
                                </div>
                                <div class="col-sm-8">
                                    <div class="text-sm-end text-right">
                                        <a href="<?php echo e(route('order.create')); ?>" class="btn btn-primary ">Add Order</a>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <table id="orders-datatable" class="table table-bordered dt-responsive  nowrap w-100">
                                <thead>
                                    <tr>
                                        <th>Invoice ID</th>
                                        <th>Customer Name</th>
                                        <th>Order Date</th>
                                        <th>Paid</th>
                                        <th>Payment Type</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div> 
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('customScript'); ?>
    <script>
        const table = $("#orders-datatable").DataTable({
            processing: true,
            serverSide: true,
            responsive: true,
            columnDefs: [{
                className: "dtr-control",
                "targets": [0]
            }],
            ajax: {
                type: "POST",
                data:{
                    _token: "<?php echo e(csrf_token()); ?>"
                },
                url: "<?php echo e(route('order.get')); ?>"
            },
            columns: [
                { data: "id" },
                { data: "customer_name" },
                { data: "order_date" },
                { data: "paid" },
                { data: "payment_type" },
                { data: "action" }
            ]
        });
        
        function delete_order(id) {
            Swal.fire({
                title: "<?php echo e(__('trans.are_you_sure')); ?>",
                text: "<?php echo e(__('trans.confirmation_warning')); ?>",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: '<?php echo e(__('trans.yes_delete')); ?>',
                cancelButtonText: '<?php echo e(__('trans.cancel')); ?>'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        type: "POST",
                        url: "<?php echo e(route('order.destroy','id')); ?>".replace('id',id),
                        data: {
                            _token: "<?php echo e(csrf_token()); ?>",
                            _method: "DELETE",
                            id: id
                        },beforeSend: function(){
                            Swal.fire({
                                title: '<?php echo e(__('trans.wait')); ?>',
                                allowOutsideClick: false,
                                didOpen: () => {
                                    Swal.showLoading()
                                    const content = Swal.getContent()
                                    if (content) {
                                        const b = content.querySelector('b')
                                        if (b) {
                                            b.textContent = Swal.getTimerLeft()
                                        }
                                    }
                                },
                            })
                        },success: function (res) {
                            console.log(res);
                            if(res == 1){
                                Swal.fire(
                                    "Deleted!",
                                    "Order Deleted",
                                    "success"
                                );
                                table.row($("#row_"+id).parent().parent()).remove().draw();
                            }else{
                                Swal.fire(
                                    "Deleted!",
                                    "Failed to delete order.Try Again!",
                                    "error"
                                )
                            }
                        },error: function (e, textStatus, errorThrown) {
                            Swal.fire(
                                "Error",
                                errorThrown,
                                "error"
                            )
                        }
                    });
                }
            })
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\salago-upgraded\resources\views/orders-listing.blade.php ENDPATH**/ ?>