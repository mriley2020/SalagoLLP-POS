    <?php $use = ['datatable']; ?>
    
    <?php $__env->startSection('customStyle'); ?>
    
    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('content'); ?>
        <div class="page-content">
            <div class="container-fluid">

              
               <canvas id="myChart"></canvas>

            </div> <!-- container-fluid -->
        </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('customScript'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
          <script>
var ctx = document.getElementById('myChart').getContext('2d');
var chart = new Chart(ctx, {
    // The type of chart to create
    type: 'bar',

    // The data for the dataset
    data: {
        labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July','August','September','November','December'],
        datasets: [{
            label: 'Sale Graph',
            backgroundColor: 'rgb(255, 99, 132)',
            borderColor: 'rgb(255, 99, 132)',
            data: [
                <?php echo e($count['jan']); ?>,
                <?php echo e($count['feb']); ?>,
                <?php echo e($count['mar']); ?>,
                <?php echo e($count['apr']); ?>,
                <?php echo e($count['may']); ?>,
                <?php echo e($count['jun']); ?>,
                <?php echo e($count['jul']); ?>,
                <?php echo e($count['aug']); ?>,
                <?php echo e($count['sep']); ?>,
                <?php echo e($count['oct']); ?>,
                <?php echo e($count['nov']); ?>,
                <?php echo e($count['dec']); ?>

            ]
        }]
    },

    // Configuration options go here
    options: {}
});




</script>
  
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\salago-upgraded\resources\views/chart.blade.php ENDPATH**/ ?>