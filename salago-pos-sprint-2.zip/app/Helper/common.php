<?php

function priceFormat($amount){
    return '£'.$amount;
}
