<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title> <?php echo e($title); ?> </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    
    <?php if (isset($component)) { $__componentOriginal06b30675f0f3b69c6ce47053bbc92b0fde209e09 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Style::class, ['use' => $use,'customStyle' => isset($customStyle) ? $customStyle : $customStyle = '']); ?>
<?php $component->withName('style'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal06b30675f0f3b69c6ce47053bbc92b0fde209e09)): ?>
<?php $component = $__componentOriginal06b30675f0f3b69c6ce47053bbc92b0fde209e09; ?>
<?php unset($__componentOriginal06b30675f0f3b69c6ce47053bbc92b0fde209e09); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
</head>

<body data-sidebar="dark">

<div id="layout-wrapper">

    <div id="layout-wrapper">

        
        <?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, []); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

        
        <?php if (isset($component)) { $__componentOriginal0ec1267fc28d6a98ac64be61eaa8884c10c1501b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Dashboard::class, []); ?>
<?php $component->withName('dashboard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal0ec1267fc28d6a98ac64be61eaa8884c10c1501b)): ?>
<?php $component = $__componentOriginal0ec1267fc28d6a98ac64be61eaa8884c10c1501b; ?>
<?php unset($__componentOriginal0ec1267fc28d6a98ac64be61eaa8884c10c1501b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

        
        <div class="main-content">

            <?php echo e(@$content); ?>


            <?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

        </div>
    </div>
</div>


<?php if (isset($component)) { $__componentOriginale897f15469526e6bb29848b9fcf70c3214246b74 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Script::class, ['use' => $use,'customScript' => isset($customScript) ? $customScript : $customScript = '']); ?>
<?php $component->withName('script'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginale897f15469526e6bb29848b9fcf70c3214246b74)): ?>
<?php $component = $__componentOriginale897f15469526e6bb29848b9fcf70c3214246b74; ?>
<?php unset($__componentOriginale897f15469526e6bb29848b9fcf70c3214246b74); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

</body>
</html>

















































<?php /**PATH E:\XAMPP\htdocs\salagoposupgraded\resources\views/layouts/main-layout.blade.php ENDPATH**/ ?>