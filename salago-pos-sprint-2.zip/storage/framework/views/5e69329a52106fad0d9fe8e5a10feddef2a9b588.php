
<script src="<?php echo e(asset('assets/libs/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/metismenu/metisMenu.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/simplebar/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/node-waves/waves.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/sweetalert2/script.js')); ?>"></script>



<?php if(auth()->guard()->check()): ?>

    <?php if(in_array('datatable',$use)): ?>
    <script src="<?php echo e(asset('assets/libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.js"></script>
    <!--<script src="<?php echo e(asset('assets/js/pages/datatables.init.js')); ?>"></script>-->
    <?php endif; ?>

    <?php if(in_array('apexcharts',$use)): ?>
    <script src="<?php echo e(asset('assets/libs/apexcharts/apexcharts.min.js')); ?>"></script>
    <?php endif; ?>
    
    <script src="<?php echo e(asset('assets/js/pages/dashboard.init.js')); ?>"></script>

    <?php if(in_array('select2',$use)): ?>
    <script src="<?php echo e(asset('assets/libs/select2/js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/pages/ecommerce-select2.init.js')); ?>"></script>
    <?php endif; ?>

    <?php if(in_array('dropzone',$use)): ?>
    <script src="<?php echo e(asset('assets/libs/dropzone/min/dropzone.min.js')); ?>"></script>
    <?php endif; ?>

<?php endif; ?>

<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>


<?php /**PATH /home/ourcanadadev/public_html/salagoposupgraded/resources/views/includes/script.blade.php ENDPATH**/ ?>