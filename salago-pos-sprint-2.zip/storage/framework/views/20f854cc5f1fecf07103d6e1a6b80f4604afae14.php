<?php if (isset($component)) { $__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MainLayout::class, ['title' => ''.e(__('trans.add_order')).'']); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('customStyle'); ?> 
        <style>
            input[disabled]{
                background: rgba(0,0,0,.05) !important;
            }
            input::-webkit-outer-spin-button,
            input::-webkit-inner-spin-button {
                -webkit-appearance: none;
                margin: 0;
            }
            input[type=number] {
                -moz-appearance: textfield;
            }
        </style>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('content'); ?> 
        <div class="page-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-flex align-items-center justify-content-between">
                            <h4 class="mb-0 font-size-18">Order Details</h4>
                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <li class="breadcrumb-item"><a href="javascript: void(0);">Orders</a></li>
                                    <li class="breadcrumb-item active">Order Details</li>
                                </ol>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="customer-name">Customer Name</label>
                                            <input type="text" class="form-control" value="<?php echo e($order->customer_name); ?>" disabled>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="date">Date</label>
                                            <input type="date" value="<?php echo e($order->order_date); ?>" class="form-control" disabled>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="table-responsive">
                                            <table class="table mb-0 table-bordered">
                                                <thead class="table-dark">
                                                    <tr>
                                                        <th width="20%">Order Product</th>
                                                        <th>Stock</th>
                                                        <th>Price</th>
                                                        <th>Product Quantity</th>
                                                        <th>Total</th>
                                                    </tr>
                                                </thead>
                                                <tbody id="product-data">
                                                    <?php $__currentLoopData = $order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <th scope="row">
                                                            <select name="product[]" onchange="setProductData($(this));" class="form-control select2">
                                                                <option value="">--Select--</option>
                                                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option
                                                                    <?php echo e($detail->product_id == $product->id ? 'selected' : ''); ?>

                                                                    data-price="<?php echo e($product->price); ?>"
                                                                    data-stock="<?php echo e($product->stock); ?>"
                                                                    value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </th>
                                                        <td><input type="number" value="<?php echo e($product->stock); ?>" class="form-control stock" disabled></td>
                                                        <td><input type="number" value="<?php echo e($detail->price); ?>" class="form-control price" disabled></td>
                                                        <td><input value="<?php echo e($detail->quantity); ?>" type="number" disabled class="form-control quantity"></td>
                                                        <td><input type="number" value="<?php echo e($detail->price * $detail->quantity); ?>" class="form-control total" disabled></td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                        <br>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label>Sub Total</label>
                                            <div class="input-group">
                                                <div class="input-group-text dIcon">$</div>
                                                <input id="subtotal" type="number" class="form-control" disabled>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="total">Total</label>
                                            <div class="input-group">
                                                <div class="input-group-text dIcon">$</div>
                                                <input id="total" type="number" class="form-control" disabled>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label>Tax (5%)</label>
                                            <div class="input-group">
                                                <div class="input-group-text dIcon">$</div>
                                                <input id="tax" type="number" class="form-control" disabled>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="paid">Paid</label>
                                            <div class="input-group">
                                                <div class="input-group-text dIcon">$</div>
                                                <input id="paid" type="number" class="form-control" value="<?php echo e($order->paid); ?>" disabled>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="discount">Discount</label>
                                            <div class="input-group">
                                                <div class="input-group-text dIcon">$</div>
                                                <input id="discount" value="<?php echo e($order->discount); ?>" type="number" disabled class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label>Due</label>
                                            <div class="input-group">
                                                <div class="input-group-text dIcon">$</div>
                                                <input type="number" id="due" class="form-control" disabled>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label>Payment Method</label>
                                            <div class="row m-0">
                                                <div class="custom-control custom-checkbox mr-3">
                                                    <input type="checkbox" disabled <?php echo e($order->payment_method == 'card' ? 'checked' : ''); ?> class="custom-control-input" value="card" name="payment_method" id="card">
                                                    <label class="custom-control-label" for="card">Card</label>
                                                </div>
                                                <div class="custom-control custom-checkbox mr-3">
                                                    <input type="checkbox" disabled <?php echo e($order->payment_method == 'cash' ? 'checked' : ''); ?> class="custom-control-input" value="cash" name="payment_method" id="cash">
                                                    <label class="custom-control-label" for="cash">Cash</label>
                                                </div>
                                                <div class="custom-control custom-checkbox mr-3">
                                                    <input type="checkbox" disabled <?php echo e($order->payment_method == 'cheque' ? 'checked' : ''); ?> class="custom-control-input" value="cheque" name="payment_method" id="cheque">
                                                    <label class="custom-control-label" for="cheque">Cheque</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('customScript'); ?> 
        <script>

            let subtotal = 0;
            let taxAmount = 0;

            function setProductData(select){
                const stock = select.find("option:selected").attr("data-stock");
                const price = select.find("option:selected").attr("data-price");
                const sel = select.parent().siblings("td");
                sel.children('.stock').val(stock);
                sel.children('.price').val(price);
                sel.children('.total').val(price * sel.children('.quantity').val());
                calculateValues();
            }

            $(document).on("keyup keypress mousewheel blur",".quantity",function () {
                const sel = $(this).parent().siblings("td");
                sel.find(".total").val(sel.find(".price").val() * $(this).val());
                calculateValues();
            });

            $("#discount").on("keyup keypress",function () {
                $("#total").val((subtotal + taxAmount) - $(this).val());
                $("#due").val((subtotal + taxAmount) - $(this).val() - $("#paid").val());
            });

            $("#paid").on("keyup keypress",function () {
                $("#due").val((subtotal + taxAmount) - $(this).val());
            });
            calculateValues();
            function calculateValues() {
                subtotal = 0;
                $("#product-data tr").each(function () {
                    subtotal += $(this).find(".price").val() * $(this).find(".quantity").val();
                });

                //Default tax is %5
                taxAmount = (subtotal * 5) / 100;
                $("#tax").val(taxAmount);
                $("#subtotal").val(subtotal);
                $("#total").val(subtotal + taxAmount);
                $("#due").val(subtotal + taxAmount - $("#paid").val());
                $("#discount").attr("max",(subtotal + taxAmount));
            }

            function addRow(){
                if($("tbody tr").length > 0){
                    $("tbody tr:first").before($("#table-row").html());
                }else{
                    $("tbody").append($("#table-row").html());
                }
            }

            function removeRow(del){
                del.parent().parent().remove();
            }

            $("#add-order").submit(function (e) {
                e.preventDefault();
                const form = $(this);
                $.ajax({
                    type: form.attr("method"),
                    url: form.attr("action"),
                    data: form.serialize(),
                    beforeSend: function () {
                        Swal.fire({
                            title: "Creating Order",
                            text: "Please Wait...",
                            allowOutsideClick: false,
                            didOpen: () => {
                                Swal.showLoading()
                                const content = Swal.getContent()
                                if (content) {
                                    const b = content.querySelector('b')
                                    if (b) {
                                        b.textContent = Swal.getTimerLeft()
                                    }
                                }
                            },
                        });
                    },success: function (res) {
                        console.log(res);
                        if(res == 1){
                            Swal.fire(
                                "Success",
                                "Order Created Successfully.",
                                "success"
                            );
                            window.location.href = "<?php echo e(route('order.index')); ?>";
                        }else if(res.errors){
                            Swal.fire(
                                "Error",
                                res.errors,
                                "error"
                            );
                        }else{
                            Swal.fire(
                                "Error",
                                "Failed to create order.Try Again!.",
                                "error"
                            );
                        }
                    },error: function (e,err,data) {
                        Swal.fire(
                            "Error",
                            err,
                            "error"
                        );
                    }
                });
            });
        </script>
     <?php $__env->endSlot(); ?>

 <?php if (isset($__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d)): ?>
<?php $component = $__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d; ?>
<?php unset($__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH E:\XAMPP\htdocs\salagoposupgraded\resources\views/view-order.blade.php ENDPATH**/ ?>