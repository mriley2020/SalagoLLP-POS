@extends('layouts.main-layout')
    <?php $use = ['datatable']; ?>
    @section('content')
        <div class="page-content">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-flex align-items-center justify-content-between">
                            <h4 class="mb-0 font-size-18">Table Report</h4>

                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <li class="breadcrumb-item"><a href="javascript: void(0);">Sales Report</a></li>
                                    <li class="breadcrumb-item active">Table Report</li>
                                </ol>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4">
                        <div class="card mini-stats-wid">
                            <div class="card-body">
                                <div class="media">
                                    <div class="media-body">
                                        <p class="text-muted font-weight-medium">Total Invoice</p>
                                        <h4 class="mb-0">{{ $totalOrders }}</h4>
                                    </div>

                                    <div class="mini-stat-icon avatar-sm rounded-circle bg-primary align-self-center">
                                        <span class="avatar-title">
                                            <i class="bx bx-copy-alt font-size-24"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card mini-stats-wid">
                            <div class="card-body">
                                <div class="media">
                                    <div class="media-body">
                                        <p class="text-muted font-weight-medium">Sub Total</p>
                                        <h4 class="mb-0">{{ $earnedAmount }}</h4>
                                    </div>

                                    <div class="avatar-sm rounded-circle bg-primary align-self-center mini-stat-icon">
                                        <span class="avatar-title rounded-circle bg-primary">
                                            <i class="bx bx-archive-in font-size-24"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card mini-stats-wid">
                            <div class="card-body">
                                <div class="media">
                                    <div class="media-body">
                                        <p class="text-muted font-weight-medium">Net Total</p>
                                        <h4 class="mb-0">{{ $earnedAmount + ($earnedAmount * 5 / 100) }}</h4>
                                    </div>

                                    <div class="avatar-sm rounded-circle bg-primary align-self-center mini-stat-icon">
                                        <span class="avatar-title rounded-circle bg-primary">
                                            <i class="bx bx-purchase-tag-alt font-size-24"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">From : -- To : </h4>
                                <br>
                                <form method="GET">
                                    <div class="row mb-4">

                                        <div class="col-sm-5">

                                            <div class="input-group">
                                                <div class="input-group-text dIcon"><i class="fa fa-calendar"></i> </div>
                                                <input type="date" name="form_date" value="{{ @$_GET['form_date'] }}" id="form_date" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-sm-5">

                                            <div class="input-group">
                                                <div class="input-group-text dIcon"><i class="fa fa-calendar"></i> </div>
                                                <input type="date" name="to_date" value="{{ @$_GET['to_date'] }}" id="to_date" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-sm-2">
                                            <button type="submit" id="filter_by_date" class="btn btn-primary w-md">Filter By Date</button>
                                        </div>
                                    </div>

                                </form>
                            </div>
                        </div>

                    </div>

                </div>


                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row mb-4">
                                    <div class="col-sm-4">
                                        <h4 class="card-title">Sales Report</h4>
                                    </div>

                                </div>
                                <br>

                                <table id="reports-datatable" class="table table-bordered dt-responsive  nowrap w-100">
                                    <thead>
                                        <tr>
                                            <th>Invoice ID</th>
                                            <th>Customer Name</th>
                                            <th>Sub Total</th>
                                            <th>Tax(5%)</th>
                                            <th>Discount</th>
                                            <th>Total</th>
                                            <th>Paid</th>
                                            <th>Due</th>
                                            <th>Order Date</th>
                                            <th>Payment Type</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div> <!-- end col -->
                </div> <!-- end row -->
            </div> <!-- container-fluid -->
        </div>
    @endsection

    @section('customScript')
        <script type="text/javascript">
            const table = $("#reports-datatable").DataTable({
                processing: true,
                serverSide: true,
                responsive: true,
                columnDefs: [{
                    className: "dtr-control",
                    "targets": [0]
                }],
                ajax: {
                    type: "POST",
                    data:{
                        _token: "{{ csrf_token() }}",
                        form_date: "{{ @$_GET['form_date'] }}",
                        to_date: "{{ @$_GET['to_date'] }}"
                    },
                    url: "{{ route('report.get') }}"
                },
                columns: [
                    { data: "invoice_id" },
                    { data: "customer_name" },
                    { data: "sub_total" },
                    { data: "tax" },
                    { data: "discount" },
                    { data: "total" },
                    { data: "paid" },
                    { data: "due" },
                    { data: "order_date" },
                    { data: "payment_type" }
                ]
            });

        </script>
    @endsection