<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class ProductController extends Controller
{

    // displaying product listing page
    public function index()
    {
        return view('products-listing');
    }
    
    // get the product record from database and converting to json format and passing to ajax datatable.
    public function getProducts(Request $request) {
     

        $products = Product::query();

        if(!empty($_POST['search']['value'])){
            $products = $products->where('name','like','%'.$_POST['search']['value'].'%');
        }

        $total = $products->count();

        $products = $products->orderBy('id','desc')->skip($request->start)->take($request->length)->get();

        $recordsFiltered = $products->count();
        $data = [];
        $i =  $request->start + 1;
        foreach ($products as $item){
            $thumbnail = explode(',',$item->image)[0];
            $data[] = [
                'id' => $i++,
                'name' => $item->name,
                'category' => $item->Category->name,
                'purchase_price' => priceFormat($item->price),
                'sale_price' => priceFormat($item->sale_price),
                'stock' => $item->stock,
                'product_image' => '<img src="storage/products-images/'.$thumbnail.'">',
                'action' =>
                    '<a href="'.route('product.show',$item->id).'" class="btn btn-sm btn-warning"><i class="fa fa-eye"></i></a>
                        <a href="'.route('product.edit',$item->id).'" class="btn btn-sm btn-success"><i class="fa fa-edit"></i> </a>
                        <a id="row_'.$item->id.'" href="javascript:void(0)" onclick="deleteProduct('.$item->id.')" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i> </a>'
            ];
        }

        $output = [
            'draw' => $request->draw,
            'recordsTotal' => $total,
            'recordsFiltered' => $recordsFiltered,
            'data' => $data
        ];

        return Response::json($output);

    }
    
    // displaying the add product page 
    public function create()
    {
        return view('add-product')->with('category_list',Category::orderBy('id','desc')->get(['id','name']));
    }

    public function validateProductForm(Request $request,$imageRequired = true){
        return Validator::make($request->all(),[
            'product_name' => ['required','string','max:100'],
            'stock' => ['required','integer','min:1','max:100000'],
            'category' => ['required','exists:categories,id'],
            'price' => ['required','numeric','min:1'],
            'sale_price' => ['required','numeric','min:1'],
            'product_description' => ['required','string','max:3000'],
            'images' => $imageRequired ? 'required' : '',
            'images.*' => $imageRequired ? 'mimes:jpeg,png,jpg,svg' : ''
        ]);
    }

    // insert product in database
    public function store(Request $request)
    {
        

        $validate = $this->validateProductForm($request);

        if($validate->fails()){
            $html = view('forms.add-product')
                ->withErrors($validate)
                ->with('category_list',Category::orderBy('id','desc')->get(['id','name']))
                ->with('old',$request->except('_token'))
                ->render();
            return Response::json(['view'=>$html,'old'=>$request->except('_token'),'errors'=>$validate->errors()]);
        }

        if($request->hasFile('images')){
            foreach($request->file('images') as $file)
            {
//                    $file->getClientOriginalName()
                $name = Str::random(5).'-'.time().'.'.$file->extension();
                $file->storeAs('public/products-images', $name);
                $imgData[] = $name;
            }
        }

        if(count($imgData) < 1){
            return Response::json(['upload_error'=>'Failed to upload images.Try Again!']);
        }

        $save = Product::create([
            'name' => $request->product_name,
            'slug' => Str::slug($request->product_name,'-').'-'.(Product::max('id') + 1),
            'category' => $request->category,
            'price' => $request->price,
            'sale_price' => $request->sale_price,
            'stock' => $request->stock,
            'description' => $request->product_description,
            'image' => implode(',',$imgData)
        ]);

        if($save){
            return Response::json(1);
        }
        return Response::json(0);
    }

    // displaying the product details
    public function show(Product $product)
    {
        return view('view-product')->with('product',$product);
    }

    public function edit(Product $product)
    {
        return view('edit-product')
            ->with('category_list',Category::orderBy('id','desc')->get(['id','name']))
            ->with('product',$product);
    }

    // updating product
    public function update(Request $request, Product $product)
    {
        if($request->ajax()){

            $validate = $this->validateProductForm($request,false);

            if($validate->fails()){
                $html = view('forms.edit-product')
                    ->withErrors($validate)
                    ->with('product',$product)
                    ->with('category_list',Category::orderBy('id','desc')->get(['id','name']))
                    ->with('old',$request->except('_token'))
                    ->render();
                return Response::json(['view'=>$html,'old'=>$request->except('_token'),'errors'=>$validate->errors()]);
            }

            $imgData = [];
            if($request->hasFile('images')){
                foreach($request->file('images') as $file){
//                    $file->getClientOriginalName()
                    $name = Str::random(5).'-'.time().'.'.$file->extension();
                    $file->storeAs('public/products-images/', $name);
                    $imgData[] = $name;
                }
            }

            $old_images = explode(',',$product->image);

            if($request->has('deletedImages') && count($request->deletedImages) > 0){
                $request->deletedImages = array_intersect($request->deletedImages,$old_images);
            }

            $new_images = $old_images;
            if($request->has('deletedImages')){
                if(count($request->deletedImages) == count($old_images) && count($imgData) < 1){
                    return Response::json(['upload_error'=>'Please upload at least one image.']);
                }else{
                    for ($i = 0; $i < count($request->deletedImages); $i++){
                        File::delete('storage/products-images/'.$request->deletedImages[$i]);
                    }
                    $new_images = array_diff($old_images,$request->deletedImages);
                }
            }

            if(count($imgData) > 0){
                for ($i = 0; $i < count($imgData); $i++){
                    array_push($new_images,$imgData[$i]);
                }
            }

            $update = $product->update([
                'name' => $request->product_name,
                'slug' => Str::slug($request->product_name,'-').'-'.$product->id,
                'category' => $request->category,
                'price' => $request->price,
                'sale_price' => $request->sale_price,
                'stock' => $request->stock,
                'description' => $request->product_description,
                'image' => implode(',',$new_images)
            ]);

            if($update){
                return Response::json(1);
            }
            return Response::json(0);
        }
        abort(403);
    }

    // deleting product
    public function destroy(Product $product)
    {
        return Response::json($product->delete());
    }
}
