<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;
use App\Models\OrderDetail;

class HomeController extends Controller
{

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    //  displaying the dashboard page with data
    public function index()
    {
        return view('dashboard')
        ->with('latestOrders',Order::orderBy('id','DESC')->limit(10)->get())
        ->with('totalOrders',Order::count('*'))
        ->with('earnedAmount',OrderDetail::sum(\DB::raw('price * quantity')))
        ->with('avgAmount',OrderDetail::avg(\DB::raw('price * quantity')));
    }
}
