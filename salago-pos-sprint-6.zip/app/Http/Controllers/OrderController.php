<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\OrderDetail;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;


class OrderController extends Controller
{

    // displaying the order listing
    public function index()
    {
        return view('orders-listing');
    }

    // get ther order's record from database and converting to json format and passing to ajax datatable.
    public function getOrders(Request $request){
      
        $order = Order::query();

        if(!empty($_POST['search']['value'])){
            $order = $order->where('name','like','%'.$_POST['search']['value'].'%');
        }

        $total = $order->count();

        $order = $order->orderBy('id','desc')->skip($request->start)->take($request->length)->get();

        $recordsFiltered = $order->count();
        $data = [];
        $i =  $request->start + 1;
        foreach ($order as $item){
            $thumbnail = explode(',',$item->image)[0];
            $oderDetail = OrderDetail::where('order_id',$item->id)->get();
            $total = 0;
            $due = 0;
            foreach($oderDetail as $detail){
                $total += $detail->price * $detail->quantity;
            }
            $data[] = [
                'id' => $i++,
                'customer_name' => $item->customer_name,
                'order_date' => $item->order_date,
                'total' => priceFormat($total),
                'paid' => priceFormat($item->paid),
                'due' => priceFormat($total - $item->paid),
                'payment_type' => ucfirst($item->payment_method),
                'action' =>
                    '<a href="'.route('order.show',$item->id).'" class="btn btn-sm btn-warning"><i class="fa fa-eye"></i></a>
                        <a href="'.route('order.edit',$item->id).'" class="btn btn-sm btn-success"><i class="fa fa-edit"></i> </a>
                        <a id="row_'.$item->id.'" href="javascript:void(0)" onclick="delete_order('.$item->id.')" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i> </a>'
            ];
        }

        $output = [
            'draw' => $request->draw,
            'recordsTotal' => $total,
            'recordsFiltered' => $recordsFiltered,
            'data' => $data
        ];

        return Response::json($output);
    }

    // displaying the add order page. with products list which is needed on the add product page for select product to order.
    public function create()
    {
        return view('add-order')->with('products',Product::orderBy('id','DESC')->get(['id','name','stock','price']));
    }

    // applying the validation on add and edit order.
    public function validateOrder(Request $request) {
        return Validator::make($request->all(),[
            'customer' => ['required'],
            'order_date' => ['required','date'],
            'tax' => ['nullable','numeric','min:0'],
            'paid' => ['required','numeric','min:0'],
            'payment_method' => ['required','in:card,cash,cheque'],
            'product' => ['required']
        ],[
            'customer_name.required' => 'Customer name is required.',
            'order_date.required' => 'Order date is required.',
            'paid.required' => 'Please enter paid amount.',
            'payment_method' => 'Please select payment method.'
        ]);
    }

    // inserting the order record in database.
    public function store(Request $request)
    {
      

        $validate = $this->validateOrder($request);

        if($validate->fails()){

            $html = '<ul>';
            foreach ($validate->getMessageBag()->all() as $error){
                $html .= '<li>'.$error.'</li>';
            }
            $html .= '</ul>';
            return Response::json(['errors'=>$html]);
        }


        $save = Order::create([
            'customer_name' => $request->customer,
            'order_date' => $request->order_date,
            'tax' => $request->tax,
            'discount' => $request->discount,
            'paid' =>  $request->paid,
            'payment_method' => $request->payment_method,
        ]);

        if($save){
            $data = [];
            for ($i = 0; $i < count($request->product); $i++){
                $product = Product::find($request->product[$i])->first();
                if($product){
                    $data[] = [
                        'order_id' => $save->id,
                        'product_id' => $request->product[$i],
                        'price' => $product->price,
                        'quantity' => $request->quantity[$i]
                    ];
                }
            }

            if(count($data) > 0){
                OrderDetail::insert($data);
                return Response::json(1);
            }else{
                Order::find($save->id)->delete();
                return Response::json(0);
            }
        }
        return Response::json(0);
    }
    
    // showing the order details page with order details..
    public function show(Order $order)
    {
        return view('view-order')
        ->with('order',$order)
        ->with('order_details',OrderDetail::where('order_id',$order->id)->get())
        ->with('products',Product::orderBy('id','DESC')->get(['id','name','stock','price']));
    }

    // showing the edit order page with order record.
    public function edit(Order $order)
    {
        return view('edit-order')
        ->with('order',$order)
        ->with('order_details',OrderDetail::where('order_id',$order->id)->get())
        ->with('products',Product::orderBy('id','DESC')->get(['id','name','stock','price']));
    }

    // updating the order record.
    public function update(Request $request, Order $order)
    {
       

        $validate = $this->validateOrder($request);

        if($validate->fails()){

            $html = '<ul>';
            foreach ($validate->getMessageBag()->all() as $error){
                $html .= '<li>'.$error.'</li>';
            }
            $html .= '</ul>';
            return Response::json(['errors'=>$html]);
        }


        $save = $order->update([
            'customer_name' => $request->customer,
            'order_date' => $request->order_date,
            'tax' => $request->tax,
            'discount' => $request->discount,
            'paid' =>  $request->paid,
            'payment_method' => $request->payment_method,
        ]);


        if($save){
            $data = [];
            for ($i = 0; $i < count($request->product); $i++){
                $product = Product::find($request->product[$i])->first();
                if($product){
                    $data[] = [
                        'order_id' => $order->id,
                        'product_id' => $request->product[$i],
                        'price' => $product->price,
                        'quantity' => $request->quantity[$i]
                    ];
                }
            }

            if(count($data) > 0){
                OrderDetail::where('order_id',$order->id)->delete();
                OrderDetail::insert($data);
                return Response::json(1);
            }else{
                return Response::json(['errors'=>'Failed to post order.No Product is selected.']);
            }
        }
        return Response::json(0);
    }
    
    
    public function destroy(Order $order)
    {
        OrderDetail::where('order_id',$order->id)->delete();
        return response()->json($order->delete());

    }
    
    // displaying the order report page
    public function reportsListing(){
        return view('report')
        ->with('totalOrders',Order::count('*'))
        ->with('earnedAmount',OrderDetail::sum(\DB::raw('price * quantity')))
        ->with('avgAmount',OrderDetail::avg(\DB::raw('price * quantity')));
    }

     // get the report record from database and converting to json format and passing to ajax datatabe.
    public function reportsRecord(Request $request) {
        
        if(empty($request->from_date) && empty($request->to_date)){
            return $output = [
                'draw' => $request->draw,
                'recordsTotal' => 0,
                'recordsFiltered' => 0,
                'data' => []
            ];

        }
        
        $order = Order::query();

        if(!empty($_POST['search']['value'])){
            $order = $order->where('customer_name','like','%'.$_POST['search']['value'].'%');
        }
        
        $order = $order->where('order_date','>=',$request->form_date);
        $order = $order->where('order_date','<=',$request->to_date);
        $total = $order->count();
        $order = $order->orderBy('id','desc')->skip($request->start)->take($request->length)->get();
        $recordsFiltered = $order->count();
        $data = [];
        $i =  $request->start + 1;
        foreach ($order as $item){
            $thumbnail = explode(',',$item->image)[0];
            $subTotal = OrderDetail::where('order_id',$item->id)->sum(\DB::raw('price * quantity'));
            $data[] = [
                'invoice_id' => $item->id,
                'customer_name' => $item->customer_name,
                'sub_total' => priceFormat($subTotal),
                'tax' => priceFormat($item->tax),
                'discount' => $item->discount,
                'total' => priceFormat($subTotal + ($item->tax * $subTotal)),
                'paid' => priceFormat($item->paid),
                'due' => priceFormat(($subTotal + ($item->tax * $subTotal)) - $item->paid),
                'order_date' => $item->order_date,
                'payment_type' => ucfirst($item->payment_method),
            ];
        }

        $output = [
            'draw' => $request->draw,
            'recordsTotal' => $total,
            'recordsFiltered' => $recordsFiltered,
            'data' => $data
        ];

        return Response::json($output);

    }
    
}
