<?php $__env->startSection('title',__('trans.view_product')); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0 font-size-18">View Product</h4>
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Products</a></li>
                                <li class="breadcrumb-item active">View Product</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row mb-4">
                                <div class="col-sm-4">
                                    <h4 class="card-title">Product Name</h4>
                                </div>
                            </div>
                            <br>
                            <div class="row">
                                <div class="col-sm-6 text-center">
                                    <img src="<?php echo e(asset('storage/products-images/'.explode(',',$product->image)[0])); ?>" alt="" class="img-fluid mx-auto d-block" style="width: 75%">
                                </div>
                                <div class="col-xl-6">
                                    <div class="mt-4 mt-xl-3">
                                        <a href="#" class="text-primary"><?php echo e($product->Category->name); ?></a>
                                        <h4 class="mt-1 mb-3"><?php echo e($product->name); ?></h4>
                                        <h5 class="mb-4">Price : <span class="text-muted me-2"><del><?php echo e(priceFormat($product->price)); ?> GPB</del></span> <b><?php echo e(priceFormat($product->sale_price)); ?> USD</b></h5>
                                        <p class="text-muted mb-4"><?php echo e($product->description); ?></p>
                                        <p class="text-muted mb-4"><b>Stock: </b> <?php echo e($product->stock); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\salago-upgraded\resources\views/view-product.blade.php ENDPATH**/ ?>