<?php if (isset($component)) { $__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MainLayout::class, ['title' => ''.e(__('trans.orders_listing')).'']); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('content'); ?> 
        <div class="page-content">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-flex align-items-center justify-content-between">
                            <h4 class="mb-0 font-size-18">Orders Listing</h4>

                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                                    <li class="breadcrumb-item active">Order Listing</li>
                                </ol>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row mb-4">
                                    <div class="col-sm-4">
                                        <h4 class="card-title">Order Listing</h4>
                                    </div>
                                    <div class="col-sm-8">
                                        <div class="text-sm-end text-right">
                                            <a href="<?php echo e(route('order.create')); ?>" class="btn btn-primary ">Add Order</a>
                                        </div>
                                    </div><!-- end col-->
                                </div>
                                <br>

                                <table id="datatable" class="table table-bordered dt-responsive  nowrap w-100">
                                    <thead>
                                    <tr>
                                        <th>Invoice ID</th>
                                        <th>Customer Name</th>
                                        <th>Order Date</th>
                                        <th>Total</th>
                                        <th>Paid</th>
                                        <th>Due</th>
                                        <th>Payment Type</th>
                                        <th>Action</th>

                                    </tr>
                                    </thead>

                                    <tbody>
                                    <?php for($i = 1 ; $i <= 10 ; $i++): ?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td>Name <?php echo e($i); ?></td>
                                            <td>2019-05-1<?php echo e($i); ?></td>
                                            <td>25<?php echo e($i); ?></td>
                                            <td>15<?php echo e($i); ?></td>
                                            <td>-1<?php echo e($i); ?></td>
                                            <td>Cash</td>
                                            <td>
                                                <a href="javascript:void(0)" class="btn btn-sm btn-warning"><i class="fa fa-print"></i></a>
                                                <a href="<?php echo e(route('order.edit',1)); ?>" class="btn btn-sm btn-success"><i class="fa fa-edit"></i> </a>
                                                <a href="javascript:void(0)" data-toggle="modal" data-target=".deleteCategory" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i> </a>
                                            </td>
                                        </tr>
                                    <?php endfor; ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div> <!-- end col -->
                </div> <!-- end row -->

            </div> <!-- container-fluid -->
        </div>

        <div class="modal fade deleteCategory" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Delete Order</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form method="post">
                        <div class="modal-body">
                            <p>Are you sure you want to delete this order?</p>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-danger" >Yes</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

 <?php if (isset($__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d)): ?>
<?php $component = $__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d; ?>
<?php unset($__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH D:\XAMPP\htdocs\salagoposupgraded\resources\views/orders-listing.blade.php ENDPATH**/ ?>