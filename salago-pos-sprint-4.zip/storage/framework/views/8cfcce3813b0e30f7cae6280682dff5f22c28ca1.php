<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                Copyright @ <script>document.write(new Date().getFullYear())</script>
            </div>
            <div class="col-sm-6">
                <div class="text-sm-right d-none d-sm-block">
                    Salago POS System V-1.0
                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH E:\XAMPP\htdocs\salagoposupgraded\resources\views/includes/footer.blade.php ENDPATH**/ ?>