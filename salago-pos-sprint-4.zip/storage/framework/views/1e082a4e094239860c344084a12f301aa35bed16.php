<!doctype html>
<html lang="en">
<head>

    <meta charset="utf-8" />
    <title><?php echo e($title); ?> </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php if (isset($component)) { $__componentOriginal06b30675f0f3b69c6ce47053bbc92b0fde209e09 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Style::class, ['use' => $use,'customStyle' => isset($customStyle) ? $customStyle : $customStyle = '']); ?>
<?php $component->withName('style'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal06b30675f0f3b69c6ce47053bbc92b0fde209e09)): ?>
<?php $component = $__componentOriginal06b30675f0f3b69c6ce47053bbc92b0fde209e09; ?>
<?php unset($__componentOriginal06b30675f0f3b69c6ce47053bbc92b0fde209e09); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

</head>

<body>

    <div class="home-btn d-none d-sm-block">
        <a href="index.html" class="text-dark"><i class="fas fa-home h2"></i></a>
    </div>
    <div class="account-pages my-5 pt-sm-5">
        <?php echo e(@$content); ?>

    </div>

    <?php if (isset($component)) { $__componentOriginale897f15469526e6bb29848b9fcf70c3214246b74 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Script::class, ['use' => $use,'customScript' => isset($customScript) ? $customScript : $customScript = '']); ?>
<?php $component->withName('script'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginale897f15469526e6bb29848b9fcf70c3214246b74)): ?>
<?php $component = $__componentOriginale897f15469526e6bb29848b9fcf70c3214246b74; ?>
<?php unset($__componentOriginale897f15469526e6bb29848b9fcf70c3214246b74); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

</body>
<!-- Mirrored from themesbrand.com/skote/layouts/vertical/auth-login.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 11 Sep 2020 11:42:42 GMT -->
</html>
<?php /**PATH D:\XAMPP\htdocs\salagoposupgraded\resources\views/layouts/auth-layout.blade.php ENDPATH**/ ?>