<div class="card card-form">
    <div class="card-body">
        <h4 class="card-title">{{ __('trans.basic_info') }}</h4>
        <p class="card-title-desc">{{ __('trans.fill_info_below') }}</p>
        <div class="row">
            <div class="col-sm-6">
                <div class="form-group product-input" style="position:relative;">
                    <label for="product-name">{{ __('trans.product_name') }}</label>
                    <small class="@error('product_name') is-invalid @enderror">{{ isset($old['product_name']) ? strlen($old['product_name']) : strlen($product->name) }} / 100</small>
                    <input id="product-name" name="product_name" maxlength="100" type="text" class="form-control @error('product_name') is-invalid @enderror" value="{{ isset($old['product_name']) ? $old['product_name'] : $product->name }}">
                    @error('product_name') <span class="error">{{ $message }}</span> @enderror
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="stock">{{ __('trans.stock') }}</label>
                    <input id="stock" name="stock" type="text" class="form-control @error('stock') is-invalid @enderror" value="{{ isset($old['stock']) ? $old['stock'] : $product->stock }}">
                    @error('stock') <span class="error">{{ $message }}</span> @enderror
                </div>
            </div>
        </div>
        <?php $sel_cate = isset($old['category']) ? $old['category'] : $product->category ?>
        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label class="control-label">{{ __('trans.category') }}</label>
                    <select class="form-control select2 @error('category') is-invalid @enderror" name="category">
                        <option value="">{{ __('trans.select_option') }}</option>
                        @foreach($category_list as $category)
                        <option @if($sel_cate == $category->id) selected @endif value="{{ $category->id }}">{{ $category->name }}</option>
                        @endforeach
                    </select>
                    @error('category') <span class="error">{{ $message }}</span> @enderror
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="purchase-price">{{ __('trans.purchase_price') }}</label>
                    <input id="purchase-price" name="price" type="text" class="form-control @error('price') is-invalid> @enderror" value="{{ isset($old['price']) ? $old['price'] : $product->price }}">
                    @error('price') <span class="error">{{ $message }}</span> @enderror
                </div>
            </div>
        </div>
        <div class="row">

            <div class="col-sm-6">
                <div class="form-group">
                    <label for="sale-price">{{ __('trans.sale_price') }}</label>
                    <input id="sale-price" name="sale_price" type="text" class="form-control @error('sale_price') is-invalid @enderror" value="{{ isset($old['sale_price']) ? $old['sale_price'] : $product->sale_price }}">
                    @error('sale_price') <span class="error">{{ $message }}</span> @enderror
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="form-group">
                    <label for="product-desc">{{ __('trans.product_desc') }}</label>
                    <textarea name="product_description" maxlength="3000" class="form-control @error('product_description') is-invalid @enderror" id="product-desc" rows="5">{{ isset($old['product_description']) ? $old['product_description'] : $product->description }}</textarea>
                    <small class="float-right">{{ isset($old['product_description']) ? strlen($old['product_description']) : strlen($product->description) }} / 3000</small>
                    @error('product_description') <span class="error">{{ $message }}</span> @enderror
                </div>
            </div>
        </div>
    </div>
</div>
