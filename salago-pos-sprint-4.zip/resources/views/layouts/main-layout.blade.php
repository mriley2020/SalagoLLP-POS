<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>@yield('title')</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php if(!isset($use)){$use = [];} ?>
    @include('includes.style')

    @yield('customStyle')

</head>

<body data-sidebar="dark">

<div id="layout-wrapper">

    <div id="layout-wrapper">

        @include('includes.header')

        @include('includes.dashboard')

        <div class="main-content">

            @yield('content')

            @include('includes.footer')

        </div>
    </div>
</div>


@include('includes.script')

@yield('customScript')

</body>
</html>





{{--<!doctype html>--}}
{{--<html lang="en">--}}
{{--<head>--}}
{{--    <meta charset="UTF-8">--}}
{{--    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">--}}
{{--    <meta http-equiv="X-UA-Compatible" content="ie=edge">--}}
{{--    <title>{{$title}}</title>--}}
{{--    <x-style :customStyle="isset($customStyle) ? $customStyle : $customStyle = ''" />--}}
{{--</head>--}}
{{--<body>--}}

{{--    @if(!@$removeHeader) <x-header /> @endif--}}

{{--    <x-dashboard />--}}

{{--    {{ @$content }}--}}

{{--    <x-footer />--}}

{{--    <x-script :customScript="isset($customScript) ? $customScript : $customScript = ''" />--}}
{{--</body>--}}
{{--</html>--}}
