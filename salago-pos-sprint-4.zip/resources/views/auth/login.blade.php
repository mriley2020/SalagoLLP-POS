@extends('layouts.auth-layout')
    @section('Login')
    {{-- Login page content --}}
    @section('content')
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6 col-xl-5">
                    <div class="card overflow-hidden">
                        <div class="bg-soft-primary">
                            <div class="row">
                                <div class="col-12">
                                    <div class="text-primary p-4">
                                        <h5 class="text-primary">{{ __('auth.auth_label') }}</h5>
                                        <p>{{ __('auth.auth_text') }}</p>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="card-body pt-0">
                            <div>
                                <a href="{{ url('index.html') }}">
                                    <div class="avatar-md profile-user-wid mb-4">
                                        <span class="avatar-title rounded-circle bg-light">
                                            <img src="{{ asset('assets/images/logo-square.jpg') }}" alt="" class="rounded-circle" height="70">
                                        </span>
                                    </div>
                                </a>
                            </div>
                            <div class="p-2">
                                <form class="form-horizontal" method="POST" action="{{ route('login') }}">
                                    @csrf
                                    <div class="form-group">
                                        <label for="username">{{ __('auth.username') }}</label>
                                        <input type="email" class="form-control @error('email') is-invalid @enderror" required id="username" name="email" placeholder="{{ __('auth.enter_username') }}">
                                        @error('email')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                        @enderror
                                    </div>

                                    <div class="form-group">
                                        <label for="password">{{ __('auth.password') }}</label>
                                        <input type="password" class="form-control @error('password') is-invalid @enderror" required id="password" name="password" placeholder="{{ __('auth.enter_password') }}">
                                        @error('password')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                        @enderror
                                    </div>

                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" name="remember" id="remember">
                                        <label class="custom-control-label" for="remember">{{ __('auth.remember_me') }}</label>
                                    </div>

                                    <div class="mt-3">
                                        <button type="submit" class="btn btn-primary btn-block waves-effect waves-light">{{ __('auth.login') }}</button>
                                    </div>
                                    @if (Route::has('password.request'))
                                    <div class="mt-4 text-center">
                                        <a href="/password" class="text-muted"><i class="mdi mdi-lock mr-1"></i> {{ __('auth.forgot_password') }}</a>
                                    </div>
                                    @endif
                                </form>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    @endsection
