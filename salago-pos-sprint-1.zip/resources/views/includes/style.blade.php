{{-- Common Required Styles Script --}}
<link rel="shortcut icon" href="{{ asset('assets/images/favicon.ico') }}">

<link href="{{ asset('assets/css/bootstrap.min.css') }}" id="bootstrap-style" rel="stylesheet" type="text/css" />

<link href="{{ asset('assets/css/icons.min.css') }}" rel="stylesheet" type="text/css" />

<link href="{{ asset('assets/css/app.min.css') }}" id="app-style" rel="stylesheet" type="text/css" />

{{-- Adding Custom Style --}}
