<!doctype html>
<html lang="en">
<head>

    <meta charset="utf-8" />
    <title>@yield('title')</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php if(!isset($use)){$use = [];} ?>
    @include('includes.style')

    @yield('customStyle')

</head>

<body>


    <div class="account-pages my-5 pt-sm-5">
        @yield('content')
    </div>

    @include('includes.script')

    @yield('customScript')

</body>
</html>
