<div class="card">
    <div class="card-body">
        <h4 class="card-title">Basic Information</h4>
        <p class="card-title-desc">Fill all information below</p>
        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="customer-name">Customer Name</label>
                    <input id="customer-name <?php $__errorArgs = ['customer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="customer" type="text" class="form-control" value="<?php echo e(isset($old['customer']) ? $old['customer'] : $order->customer_name); ?>">
                    <?php $__errorArgs = ['customer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="date">Date</label>
                    <input id="date" name="order_date" type="date" value="<?php echo e(isset($old['date']) ? $old['date'] : $order->order_date); ?>" class="form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="table-responsive">
                    <table class="table mb-0 table-bordered">
                        <thead class="table-dark">
                            <tr>
                                <th width="20%">Search Product</th>
                                <th>Stock</th>
                                <th>Price</th>
                                <th>Enter Quantity</th>
                                <th>Total</th>
                                <th><button type="button" onclick="addRow();" class="btn btn-sm btn-primary"><i class="fa fa-plus"></i> </button> </th>
                            </tr>
                        </thead>
                        <tbody id="product-data">
                            <?php $__currentLoopData = $order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row">
                                    <select name="product[]" onchange="setProductData($(this));" class="form-control select2">
                                        <option value="">--Select--</option>
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                            <?php echo e($detail->product_id == $product->id ? 'selected' : ''); ?>

                                            data-price="<?php echo e($product->price); ?>"
                                            data-stock="<?php echo e($product->stock); ?>"
                                            value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </th>
                                <td><input type="number" value="<?php echo e($product->stock); ?>" class="form-control stock" disabled></td>
                                <td><input type="number" value="<?php echo e($detail->price); ?>" class="form-control price" disabled></td>
                                <td><input value="<?php echo e($detail->quantity); ?>" name="quantity[]" type="number" class="form-control quantity"></td>
                                <td><input type="number" value="<?php echo e($detail->price * $detail->quantity); ?>" class="form-control total" disabled></td>
                                <td><button type="button" onclick="removeRow($(this));" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i> </button></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <br>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Sub Total</label>
                    <div class="input-group">
                        <div class="input-group-text dIcon">£</div>
                        <input id="subtotal" type="number" class="form-control" disabled>
                    </div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="total">Total</label>
                    <div class="input-group">
                        <div class="input-group-text dIcon">£</div>
                        <input id="total" type="number" class="form-control" disabled>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Tax (5%)</label>
                    <div class="input-group">
                        <div class="input-group-text dIcon">£</div>
                        <input id="tax" type="number" class="form-control" disabled>
                    </div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="paid">Paid</label>
                    <div class="input-group">
                        <div class="input-group-text dIcon">£</div>
                        <input id="paid" type="number" class="form-control <?php $__errorArgs = ['paid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="paid" value="<?php echo e(isset($old['paid']) ? $old['paid'] : $order->paid); ?>">
                        <?php $__errorArgs = ['paid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="discount">Discount</label>
                    <div class="input-group">
                        <div class="input-group-text dIcon">£</div>
                        <input id="discount" name="discount <?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(@$old['discount']); ?>" type="number" class="form-control">
                        <?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Due</label>
                    <div class="input-group">
                        <div class="input-group-text dIcon">£</div>
                        <input type="number" id="due" class="form-control" disabled>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Payment Method</label>
                    <div class="row m-0">
                        <?php $match_data = isset($old['card']) ? $old['card'] : $order->payment_method; ?>
                        <div class="custom-control custom-checkbox mr-3">
                            <input type="radio" <?php echo e($match_data == 'card' ? 'checked' : ''); ?> class="custom-control-input" value="card" name="payment_method" id="card">
                            <label class="custom-control-label" for="card">Card</label>
                        </div>
                        <div class="custom-control custom-checkbox mr-3">
                            <input type="radio" <?php echo e($match_data == 'cash' ? 'checked' : ''); ?> class="custom-control-input" value="cash" name="payment_method" id="cash">
                            <label class="custom-control-label" for="cash">Cash</label>
                        </div>
                        <div class="custom-control custom-checkbox mr-3">
                            <input type="radio" <?php echo e($match_data == 'cheque' ? 'checked' : ''); ?> class="custom-control-input" value="cheque" name="payment_method" id="cheque">
                            <label class="custom-control-label" for="cheque">Cheque</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <button type="submit" class="btn btn-primary mr-1 waves-effect waves-light">Update Order</button>
        <button type="reset" class="btn btn-secondary waves-effect">Clear</button>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\salago-upgraded\resources\views/forms/edit-order.blade.php ENDPATH**/ ?>