
<link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>">

<link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" id="bootstrap-style" rel="stylesheet" type="text/css" />

<link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />

<link href="<?php echo e(asset('assets/css/app.min.css')); ?>" id="app-style" rel="stylesheet" type="text/css" />


<?php /**PATH C:\xampp\htdocs\salago-upgraded\resources\views/includes/style.blade.php ENDPATH**/ ?>