{{-- Common Required Scripts --}}
<script src="{{ asset('assets/libs/jquery/jquery.min.js') }}"></script>
<script src="{{ asset('assets/libs/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('assets/libs/metismenu/metisMenu.min.js') }}"></script>
<script src="{{ asset('assets/libs/simplebar/simplebar.min.js') }}"></script>
<script src="{{ asset('assets/libs/node-waves/waves.min.js') }}"></script>
<script src="{{ asset('assets/sweetalert2/script.js') }}"></script>
{{--<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/10.15.6/sweetalert2.min.js" integrity="sha512-poQmMXUOqVO4qI+eioci9BPW1DfUZScDgUzPLHqlt45OI9i+f2VnbrC/cElRRilAVI1buIy7rikcLCjrXbGB4A==" crossorigin="anonymous"></script>--}}

{{-- Scripts Need On Authenticated Pages --}}
@auth()

    @if(in_array('datatable',$use))
    <script src="{{ asset('assets/libs/datatables.net/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js') }}"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.js"></script>
    @endif

    @if(in_array('select2',$use))
    <script src="{{ asset('assets/libs/select2/js/select2.min.js') }}"></script>
    <script src="{{ asset('assets/js/ecommerce-select2.init.js') }}"></script>
    @endif

    @if(in_array('dropzone',$use))
    <script src="{{ asset('assets/libs/dropzone/min/dropzone.min.js') }}"></script>
    @endif

@endauth

<script src="{{ asset('assets/js/app.js') }}"></script>

{{-- Adding Custom Script --}}
