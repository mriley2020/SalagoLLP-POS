<div class="card">
    <div class="card-body">
        <h4 class="card-title">Basic Information</h4>
        <p class="card-title-desc">Fill all information below</p>
        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="customer-name">Customer Name</label>
                    <input id="customer-name @error('customer') is-invalid @enderror" name="customer" type="text" class="form-control" value="{{ isset($old['customer']) ? $old['customer'] : $order->customer_name }}">
                    @error('customer') <span class="error">{{ $message }}</span> @enderror
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="date">Date</label>
                    <input id="date" name="order_date" type="date" value="{{ isset($old['date']) ? $old['date'] : $order->order_date }}" class="form-control @error('date') is-invalid @enderror">
                    @error('date') <span class="error">{{ $message }}</span> @enderror
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="table-responsive">
                    <table class="table mb-0 table-bordered">
                        <thead class="table-dark">
                            <tr>
                                <th width="20%">Search Product</th>
                                <th>Stock</th>
                                <th>Price</th>
                                <th>Enter Quantity</th>
                                <th>Total</th>
                                <th><button type="button" onclick="addRow();" class="btn btn-sm btn-primary"><i class="fa fa-plus"></i> </button> </th>
                            </tr>
                        </thead>
                        <tbody id="product-data">
                            @foreach($order_details as $detail)
                            <tr>
                                <th scope="row">
                                    <select name="product[]" onchange="setProductData($(this));" class="form-control select2">
                                        <option value="">--Select--</option>
                                        @foreach($products as $product)
                                        <option
                                            {{ $detail->product_id == $product->id ? 'selected' : '' }}
                                            data-price="{{ $product->price }}"
                                            data-stock="{{ $product->stock }}"
                                            value="{{ $product->id }}">{{ $product->name }}</option>
                                        @endforeach
                                    </select>
                                </th>
                                <td><input type="number" value="{{ $product->stock }}" class="form-control stock" disabled></td>
                                <td><input type="number" value="{{ $detail->price }}" class="form-control price" disabled></td>
                                <td><input value="{{ $detail->quantity }}" name="quantity[]" type="number" class="form-control quantity"></td>
                                <td><input type="number" value="{{ $detail->price * $detail->quantity }}" class="form-control total" disabled></td>
                                <td><button type="button" onclick="removeRow($(this));" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i> </button></td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                <br>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Sub Total</label>
                    <div class="input-group">
                        <div class="input-group-text dIcon">£</div>
                        <input id="subtotal" type="number" class="form-control" disabled>
                    </div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="total">Total</label>
                    <div class="input-group">
                        <div class="input-group-text dIcon">£</div>
                        <input id="total" type="number" class="form-control" disabled>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Tax (5%)</label>
                    <div class="input-group">
                        <div class="input-group-text dIcon">£</div>
                        <input id="tax" type="number" class="form-control" disabled>
                    </div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="paid">Paid</label>
                    <div class="input-group">
                        <div class="input-group-text dIcon">£</div>
                        <input id="paid" type="number" class="form-control @error('paid') is-invalid @enderror" name="paid" value="{{ isset($old['paid']) ? $old['paid'] : $order->paid }}">
                        @error('paid') <span class="error">{{ $message }}</span> @enderror
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="discount">Discount</label>
                    <div class="input-group">
                        <div class="input-group-text dIcon">£</div>
                        <input id="discount" name="discount @error('discount') is-invalid @enderror" value="{{ @$old['discount'] }}" type="number" class="form-control">
                        @error('discount') <span class="error">{{ $message }}</span> @enderror
                    </div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Due</label>
                    <div class="input-group">
                        <div class="input-group-text dIcon">£</div>
                        <input type="number" id="due" class="form-control" disabled>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Payment Method</label>
                    <div class="row m-0">
                        <?php $match_data = isset($old['card']) ? $old['card'] : $order->payment_method; ?>
                        <div class="custom-control custom-checkbox mr-3">
                            <input type="radio" {{ $match_data == 'card' ? 'checked' : '' }} class="custom-control-input" value="card" name="payment_method" id="card">
                            <label class="custom-control-label" for="card">Card</label>
                        </div>
                        <div class="custom-control custom-checkbox mr-3">
                            <input type="radio" {{ $match_data == 'cash' ? 'checked' : '' }} class="custom-control-input" value="cash" name="payment_method" id="cash">
                            <label class="custom-control-label" for="cash">Cash</label>
                        </div>
                        <div class="custom-control custom-checkbox mr-3">
                            <input type="radio" {{ $match_data == 'cheque' ? 'checked' : '' }} class="custom-control-input" value="cheque" name="payment_method" id="cheque">
                            <label class="custom-control-label" for="cheque">Cheque</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <button type="submit" class="btn btn-primary mr-1 waves-effect waves-light">Update Order</button>
        <button type="reset" class="btn btn-secondary waves-effect">Clear</button>
    </div>
</div>
