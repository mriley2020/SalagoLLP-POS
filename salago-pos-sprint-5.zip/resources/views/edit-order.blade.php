@extends('layouts.main-layout')

@section('title',__('trans.edit_order'))
    
@section('customStyle')
    <style>
        input[disabled]{
            background: rgba(0,0,0,.05) !important;
        }
        input::-webkit-outer-spin-button,
        input::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }
        input[type=number] {
            -moz-appearance: textfield;
        }
    </style>
@endsection

@section('content')
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0 font-size-18">Edit Order</h4>
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Orders</a></li>
                                <li class="breadcrumb-item active">Edit Order</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <form method="PUT" action="{{ route('order.update',$order->id) }}" id="update-order">
                        @csrf
                        @include('forms.edit-order')
                    </form>
                </div>
            </div>
        </div>
    </div>

    <template id="table-row">
        <tr>
            <th scope="row">
                <select name="product[]" onchange="setProductData($(this));" class="form-control select2">
                    <option value="">--Select--</option>
                    @foreach($products as $product)
                        <option
                            data-price="{{ $product->price }}"
                            data-stock="{{ $product->stock }}"
                            value="{{ $product->id }}">{{ $product->name }}</option>
                    @endforeach
                </select>
            </th>
            <td><input type="number" class="form-control stock" disabled></td>
            <td><input type="number" class="form-control price" disabled></td>
            <td><input value="1" min="1" name="quantity[]" type="number" class="form-control quantity"></td>
            <td><input type="number" class="form-control total" disabled></td>
            <td><button type="button" onclick="removeRow($(this));" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i> </button></td>
    </template>
@endsection
    
@section('customScript')
    <script>

        let subtotal = 0;
        let taxAmount = 0;

        function setProductData(select){
            const stock = select.find("option:selected").attr("data-stock");
            const price = select.find("option:selected").attr("data-price");
            const sel = select.parent().siblings("td");
            sel.children('.stock').val(stock);
            sel.children('.price').val(price);
            sel.children('.total').val(price * sel.children('.quantity').val());
            calculateValues();
        }

        $(document).on("keyup keypress mousewheel blur",".quantity",function () {
            const sel = $(this).parent().siblings("td");
            sel.find(".total").val(sel.find(".price").val() * $(this).val());
            calculateValues();
        });

        $("#discount").on("keyup keypress",function () {
            $("#total").val((subtotal + taxAmount) - $(this).val());
            $("#due").val((subtotal + taxAmount) - $(this).val() - $("#paid").val());
        });

        $("#paid").on("keyup keypress",function () {
            $("#due").val((subtotal + taxAmount) - $(this).val());
        });

        function calculateValues() {
            subtotal = 0;
            $("#product-data tr").each(function () {
                subtotal += $(this).find(".price").val() * $(this).find(".quantity").val();
            });

            //Default tax is %5
            taxAmount = (subtotal * 5) / 100;
            $("#tax").val(taxAmount);
            $("#subtotal").val(subtotal);
            $("#total").val(subtotal + taxAmount);
            $("#due").val(subtotal + taxAmount - $("#paid").val());
            $("#discount").attr("max",(subtotal + taxAmount));
        }calculateValues();

        function addRow(){
            if($("tbody tr").length > 0){
                $("tbody tr:first").before($("#table-row").html());
            }else{
                $("tbody").append($("#table-row").html());
            }
        }

        function removeRow(del){
            del.parent().parent().remove();
        }

        $("#update-order").submit(function (e) {
            e.preventDefault();
            const form = $(this);
            $.ajax({
                type: form.attr("method"),
                url: form.attr("action"),
                data: form.serialize(),
                beforeSend: function () {
                    Swal.fire({
                        title: "Creating Order",
                        text: "Please Wait...",
                        allowOutsideClick: false,
                        didOpen: () => {
                            Swal.showLoading()
                            const content = Swal.getContent()
                            if (content) {
                                const b = content.querySelector('b')
                                if (b) {
                                    b.textContent = Swal.getTimerLeft()
                                }
                            }
                        },
                    });
                },success: function (res) {
                    console.log(res);
                    if(res == 1){
                        Swal.fire(
                            "Success",
                            "Order Update Successfully.",
                            "success"
                        );
                        // window.location.href = "{{ route('order.index') }}";
                    }else if(res.errors){
                        Swal.fire(
                            "Error",
                            res.errors,
                            "error"
                        );
                    }else{
                        Swal.fire(
                            "Error",
                            "Failed to update order.Try Again!.",
                            "error"
                        );
                    }
                },error: function (e,err,data) {
                    Swal.fire(
                        "Error",
                        err,
                        "error"
                    );
                }
            });
        });
    </script>
@endsection
