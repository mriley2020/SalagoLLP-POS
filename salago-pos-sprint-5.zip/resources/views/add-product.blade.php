@extends('layouts.main-layout')
<?php $use = ['dropzone','select2']; ?>
@section('title','Add Product')
@section('customStyle')
    <style>
        .product-input input{
            padding-right: 55px;
        }
        .product-input small{
            right: 10px;
            line-height: 40px;
            position:absolute;
        }
        .product-input small.is-invalid{
            right: 30px;
        }
    </style>
@endsection

@section('content')
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0 font-size-18">Add Product</h4>

                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Products</a></li>
                                <li class="breadcrumb-item active">Add Product</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <form id="add-product" method="POST" action="{{ route('product.store') }}">
                        @include('forms.add-product')
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title mb-3">Product Images</h4>
                                <div class="dropzone" style="cursor:pointer;">
                                    <div class="fallback">
                                        <input name="file" style="display: none;" type="file" multiple />
                                    </div>
                                    <div class="dz-message needsclick" onclick="$('input[type=file]').click();">
                                        <div class="mb-3">
                                            <i class="display-4 text-muted bx bxs-cloud-upload"></i>
                                        </div>
                                        <h4>Drop files here or click to upload.</h4>
                                    </div>
                                </div>
                                @csrf
                                <br>
                                <button type="submit" class="btn btn-primary mr-1 waves-effect waves-light">Add Product</button>
                                <a href="{{ route('product.create') }}" class="btn btn-secondary waves-effect">Cancel</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('customScript')
    <script>

        Dropzone.autoDiscover = false;
        let images = [];
        const myDropzone = new Dropzone(".dropzone",{
            addRemoveLinks: true,
            acceptedFiles: ".jpeg,.jpg,.png,.svg",
            url: "{{ route('dropzone') }}",
            headers : {
                "X-CSRF-TOKEN" : "{{ csrf_token() }}"
            },
            init: function () {
                const dropzone = this;
                this.on('complete', function (file, xhr, formData){
                    images = dropzone;
                });
            }
        });

        $("#add-product").submit(function (e) {
            e.preventDefault();
            const form = $(this);
            const formData = new FormData(form[0]);
            if(images.length !== 0 && images.files.length > 0){
                for (let i = 0; i < images.files.length; i++){
                    formData.append("images[]",images.files[i]);
                }
            }else{
                Swal.fire(
                    "Error",
                    "Please upload at least one image.",
                    "error"
                );
                return false;
            }
            $.ajax({
                type: form.attr("method"),
                url: form.attr("action"),
                data: formData,
                enctype: "multipart/form-data",
                cache:false,
                contentType: false,
                processData: false,
                beforeSend: function () {
                    Swal.fire({
                        title: "Uploading Product",
                        text: "Please Wait...",
                        allowOutsideClick: false,
                        didOpen: () => {
                            Swal.showLoading()
                            const content = Swal.getContent()
                            if (content) {
                                const b = content.querySelector('b')
                                if (b) {
                                    b.textContent = Swal.getTimerLeft()
                                }
                            }
                        },
                    });
                },success: function (res) {
                    if(res === 1){
                        form[0].reset();
                        $(".select2").val("").trigger("change");
                        myDropzone.removeAllFiles(true);
                        Swal.fire(
                            "Success",
                            "Product Created",
                            "success"
                        );
                    }else{
                        $(".card-form").html(res.view);
                        if(res.upload_error){
                            Swal.fire(
                                "Error",
                                res.upload_error,
                                "error"
                            );
                        }else{
                            swal.close();
                        }
                    }
                },error: function (e, textStatus, errorThrown) {
                    Swal.fire(
                        "Error",
                        errorThrown,
                        "error"
                    );
                }
            });
        });

        $(document).on("keyup keydown","#product-name,#product-desc",function () {
            if($(this).attr("id") === "product-desc"){
                $(this).siblings('small').text($(this).val().length + '/ 3000');
            }else{
                $(this).siblings('small').text($(this).val().length + '/ 100');
            }
        });

    </script>
@endsection