<?php if (isset($component)) { $__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MainLayout::class, ['title' => ''.e(__('trans.add_product')).'','use' => ['dropzone','select2']]); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('customStyle'); ?> 
        <style>
            .product-input input{
                padding-right: 55px;
            }
            .product-input small{
                right: 10px;
                line-height: 40px;
                position:absolute;
            }
            .product-input small.is-invalid{
                right: 30px;
            }
        </style>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('content'); ?> 
        <div class="page-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-flex align-items-center justify-content-between">
                            <h4 class="mb-0 font-size-18"><?php echo e(__('trans.add_product')); ?></h4>

                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e(__('trans.products')); ?></a></li>
                                    <li class="breadcrumb-item active"><?php echo e(__('trans.add_product')); ?></li>
                                </ol>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <form id="add-product" method="POST" action="<?php echo e(route('product.store')); ?>">
                            <?php echo $__env->make('forms.add-product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title mb-3"><?php echo e(__('trans.product_image')); ?></h4>
                                    <div class="dropzone" style="cursor:pointer;">
                                        <div class="fallback">
                                            <input name="file" style="display: none;" type="file" multiple />
                                        </div>
                                        <div class="dz-message needsclick" onclick="$('input[type=file]').click();">
                                            <div class="mb-3">
                                                <i class="display-4 text-muted bx bxs-cloud-upload"></i>
                                            </div>
                                            <h4><?php echo e(__('trans.dropzone_placeholder')); ?></h4>
                                        </div>
                                    </div>
                                    <?php echo csrf_field(); ?>
                                    <br>
                                    <button type="submit" class="btn btn-primary mr-1 waves-effect waves-light"><?php echo e(__('trans.add_product')); ?></button>
                                    <a href="<?php echo e(route('product.create')); ?>" class="btn btn-secondary waves-effect"><?php echo e(__('trans.cancel')); ?></a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('customScript'); ?> 
        <script>

            Dropzone.autoDiscover = false;
            let images = [];
            const myDropzone = new Dropzone(".dropzone",{
                addRemoveLinks: true,
                acceptedFiles: ".jpeg,.jpg,.png,.svg",
                url: "<?php echo e(route('dropzone')); ?>",
                headers : {
                    "X-CSRF-TOKEN" : "<?php echo e(csrf_token()); ?>"
                },
                init: function () {
                    const dropzone = this;
                    this.on('complete', function (file, xhr, formData){
                        images = dropzone;
                    });
                }
            });

            $("#add-product").submit(function (e) {
                e.preventDefault();
                const form = $(this);
                const formData = new FormData(form[0]);
                if(images.length != 0 && images.files.length > 0){
                    for (let i = 0; i < images.files.length; i++){
                        formData.append("images[]",images.files[i]);
                    }
                }else{
                    Swal.fire(
                        "<?php echo e(__('trans.error')); ?>",
                        "<?php echo e(__('validation.dropzone_file_required')); ?>",
                        "error"
                    );
                    return false;
                }
                $.ajax({
                    type: form.attr("method"),
                    url: form.attr("action"),
                    data: formData,
                    enctype: "multipart/form-data",
                    cache:false,
                    contentType: false,
                    processData: false,
                    beforeSend: function () {
                        Swal.fire({
                            title: "Uploading Product",
                            text: "<?php echo e(__('trans.wait')); ?>",
                            allowOutsideClick: false,
                            didOpen: () => {
                                Swal.showLoading()
                                const content = Swal.getContent()
                                if (content) {
                                    const b = content.querySelector('b')
                                    if (b) {
                                        b.textContent = Swal.getTimerLeft()
                                    }
                                }
                            },
                        });
                    },success: function (res) {
                        if(res == true || res == 'true' || res == 1){
                            form[0].reset();
                            $(".select2").val("").trigger("change");
                            myDropzone.removeAllFiles(true);
                            Swal.fire(
                                "<?php echo e(__('trans.success')); ?>",
                                "<?php echo e(__('trans.product_created')); ?>",
                                "success"
                            );
                        }else{
                            $(".card-form").html(res.view);
                            if(res.upload_error){
                                Swal.fire(
                                    "<?php echo e(__('trans.error')); ?>",
                                    res.upload_error,
                                    "error"
                                );
                            }else{
                                swal.close();
                            }
                        }
                    },error: function (e, textStatus, errorThrown) {
                        Swal.fire(
                            "<?php echo e(__('trans.error')); ?>",
                            errorThrown,
                            "error"
                        );
                    }
                });
            });

            $(document).on("keyup keydown","#product-name,#product-desc",function () {
                if($(this).attr("id") == "product-desc"){
                    $(this).siblings('small').text($(this).val().length + '/ 3000');
                }else{
                    $(this).siblings('small').text($(this).val().length + '/ 100');
                }
            });

        </script>
     <?php $__env->endSlot(); ?>

 <?php if (isset($__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d)): ?>
<?php $component = $__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d; ?>
<?php unset($__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH D:\XAMPP\htdocs\salagoposupgraded\resources\views/add-product.blade.php ENDPATH**/ ?>