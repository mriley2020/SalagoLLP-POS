<?php if (isset($component)) { $__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MainLayout::class, ['title' => ''.e(__('trans.categories')).'','use' => ['datatable']]); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('content'); ?> 
        <div class="page-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-flex align-items-center justify-content-between">
                            <h4 class="mb-0 font-size-18"><?php echo e(__('trans.categories')); ?></h4>
                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e(__('trans.dashboard')); ?></a></li>
                                    <li class="breadcrumb-item active"><?php echo e(__('trans.categories')); ?></li>
                                </ol>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title"><?php echo e(__('trans.category_form')); ?></h4>
                                <br>
                                <form id="store-category" method="POST" action="<?php echo e(route('category.store')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="row mb-4">
                                        <label for="category-name" class="col-sm-2 col-form-label text-right"><?php echo e(__('trans.category')); ?></label>
                                        <div class="col-sm-7">
                                            <input type="text" class="form-control" name="category" id="category-name">
                                            <span class="error category-error"></span>
                                        </div>
                                        <div class="col-sm-3">
                                            <button type="submit" class="btn btn-primary w-md"><?php echo e(__('trans.submit')); ?></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title"><?php echo e(__('trans.category_listing')); ?></h4>
                                <br>
                                <table id="categories-datatable" class="table table-bordered dt-responsive  nowrap w-100">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th><?php echo e(__('trans.category')); ?></th>
                                        <th><?php echo e(__('trans.action')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('customScript'); ?> 
        <script>

            const table = $("#categories-datatable").DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    type: "POST",
                    data:{
                        _token: "<?php echo e(csrf_token()); ?>"
                    },
                    url: "<?php echo e(route('category.get')); ?>"
                },
                columns: [
                    { data: "id" },
                    { data: "name" },
                    { data: "action" }
                ]
            });

            $("#store-category").submit(function (e) {
                e.preventDefault();
                const form = $(this);
                $.ajax({
                    type: form.attr("method"),
                    url: form.attr("action"),
                    data: form.serialize(),
                    beforeSend: function () {
                        form.find("button[type=submit]").html("<?php echo e(__('trans.wait')); ?>");
                        form.find("button[type=submit]").prop("disabled",true);
                    },success: function (data) {
                        form.find("button[type=submit]").html("<?php echo e(__('trans.submit')); ?>");
                        form.find("button[type=submit]").prop("disabled",false);
                        $("#category-name").removeClass("is-invalid");
                        $(".category-error").text("");
                        $("#category-name").val("");
                        if(data.res){
                            Swal.fire(
                                "<?php echo e(__('trans.success')); ?>",
                                "<?php echo e(__('trans.category_created')); ?>",
                                "success"
                            );
                            table.ajax.reload();
                        }else{
                            Swal.fire(
                                "<?php echo e(__('trans.error')); ?>",
                                "<?php echo e(__('trans.category_create_error')); ?>",
                                "error"
                            );
                        }
                    },error: function (e, textStatus, errorThrown) {
                        form.find("button[type=submit]").html("<?php echo e(__('trans.submit')); ?>");
                        form.find("button[type=submit]").prop("disabled",false);
                        if(e.responseJSON.errors){
                            let errors = e.responseJSON.errors;
                            if(errors.category[0]){
                                $("#category-name").addClass("is-invalid");
                                $(".category-error").text(e.responseJSON.errors.category[0]);
                            }
                        }else{
                            Swal.fire(
                                "<?php echo e(__('trans.error')); ?>",
                                errorThrown,
                                "error"
                            );
                        }
                    }
                });
            });

            function delete_category(id) {
                Swal.fire({
                    title: "<?php echo e(__('trans.are_you_sure')); ?>",
                    text: "<?php echo e(__('trans.confirmation_warning')); ?>",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: '<?php echo e(__('trans.yes_delete')); ?>',
                    cancelButtonText: '<?php echo e(__('trans.cancel')); ?>'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            type: "POST",
                            url: "<?php echo e(route('category.destroy','id')); ?>".replace('id',id),
                            data: {
                                _token: "<?php echo e(csrf_token()); ?>",
                                _method: "DELETE",
                                id: id
                            },beforeSend: function(){
                                Swal.fire({
                                    title: '<?php echo e(__('trans.wait')); ?>',
                                    allowOutsideClick: false,
                                    didOpen: () => {
                                        Swal.showLoading()
                                        const content = Swal.getContent()
                                        if (content) {
                                            const b = content.querySelector('b')
                                            if (b) {
                                                b.textContent = Swal.getTimerLeft()
                                            }
                                        }
                                    },
                                })
                            },success: function (res) {
                                console.log(res);
                                if(res == 'true' || res == true || res == 1){
                                    Swal.fire(
                                        "Deleted!",
                                        "<?php echo e(__('trans.category_deleted')); ?>",
                                        "success"
                                    );
                                    table.row($("#row_"+id).parent().parent()).remove().draw();
                                }else{
                                    Swal.fire(
                                        "Deleted!",
                                        "<?php echo e(__('trans.category_delete_error')); ?>",
                                        "error"
                                    )
                                }
                            },error: function (e, textStatus, errorThrown) {
                                Swal.fire(
                                    "Error",
                                    errorThrown,
                                    "error"
                                )
                            }
                        });
                    }
                })
            }

            function edit_category(btn) {
                Swal.fire({
                  title: '<?php echo e(__('trans.update_category')); ?>',
                  input: 'text',
                  inputValue: btn.attr("data-name"),
                  inputAttributes: {
                    autocapitalize: 'off',
                    required: 'required',
                  },
                  showCancelButton: true,
                  confirmButtonText: '<?php echo e(__('trans.update')); ?>',
                  cancelButtonText: '<?php echo e(__('trans.cancel')); ?>',
                  showLoaderOnConfirm: true,
                  preConfirm: (name) => {
                    $.ajax({
                        type: "POST",
                        url: "<?php echo e(route('category.update','id')); ?>".replace('id',btn.attr("data-id")),
                        data: {
                            _token: "<?php echo e(csrf_token()); ?>",
                            _method: "PUT",
                            id: btn.attr("data-id"),
                            name: name
                        },beforeSend: function(){
                            Swal.fire({
                                title: '<?php echo e(__('trans.wait')); ?>',
                                allowOutsideClick: false,
                                didOpen: () => {
                                    Swal.showLoading()
                                    const content = Swal.getContent()
                                    if (content) {
                                        const b = content.querySelector('b')
                                        if (b) {
                                            b.textContent = Swal.getTimerLeft()
                                        }
                                    }
                                },
                            })
                        },success: function (res) {
                            console.log(res);
                            if(res == 'true' || res == true || res == 1){
                                Swal.fire(
                                    "Success",
                                    "<?php echo e(__('trans.category_updated')); ?>",
                                    "success"
                                ).then((e) => {
                                    table.ajax.reload();
                                });
                            }else{
                                Swal.fire(
                                    "Error",
                                    "<?php echo e(__('trans.category_update_error')); ?>",
                                    "error"
                                )
                            }
                        },error: function (e, textStatus, errorThrown) {
                            if(e.responseJSON.errors){
                                let errors = e.responseJSON.errors;
                                if(errors.name[0]){
                                    Swal.fire(
                                        "Error",
                                         e.responseJSON.errors.name[0],
                                        "error"
                                    );
                                }
                            }else{
                                Swal.fire(
                                    "Error",
                                    errorThrown,
                                    "error"
                                );
                            }
                        }
                    });
                  },
                  allowOutsideClick: () => !Swal.isLoading()
                })
            }

        </script>
     <?php $__env->endSlot(); ?>

 <?php if (isset($__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d)): ?>
<?php $component = $__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d; ?>
<?php unset($__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH E:\XAMPP\htdocs\salagoposupgraded\resources\views/categories.blade.php ENDPATH**/ ?>