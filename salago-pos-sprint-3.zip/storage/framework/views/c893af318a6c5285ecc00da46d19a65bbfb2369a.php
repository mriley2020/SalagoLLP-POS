<?php if (isset($component)) { $__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MainLayout::class, ['title' => ''.e(__('trans.products_listing')).'','use' => ['datatable']]); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('customStyle'); ?> 
        <style>
            td:nth-child(7){
                text-align: center;
            }
            td:nth-child(7) img{
                max-width: 200px;
                max-height: 200px;
            }
        </style>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('content'); ?> 
        <div class="page-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-flex align-items-center justify-content-between">
                            <h4 class="mb-0 font-size-18">Add Product</h4>
                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                                    <li class="breadcrumb-item active">Add Product</li>
                                </ol>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row mb-4">
                                    <div class="col-sm-4">
                                        <h4 class="card-title">Products</h4>
                                    </div>
                                    <div class="col-sm-8">
                                        <div class="text-sm-end text-right">
                                            <a href="<?php echo e(route('product.create')); ?>" class="btn btn-primary ">Add Product</a>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <table id="products-datatable" class="table table-bordered dt-responsive  nowrap w-100">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Product</th>
                                        <th>Category</th>
                                        <th>Purchase Price</th>
                                        <th>Sale Price</th>
                                        <th>Stock</th>
                                        <th>Product Image</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade deleteCategory" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Delete Product</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form method="post">
                        <div class="modal-body">
                            <p>Are you sure you want to delete this product?</p>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-danger" >Yes</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('customScript'); ?> 
        <script>

            const table = $("#products-datatable").DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    type: "POST",
                    data:{
                        _token: "<?php echo e(csrf_token()); ?>"
                    },
                    url: "<?php echo e(route('product.get')); ?>"
                },
                columns: [
                    { data: "id" },
                    { data: "name" },
                    { data: "category" },
                    { data: "purchase_price" },
                    { data: "sale_price" },
                    { data: "stock" },
                    { data: "product_image" },
                    { data: "action" }
                ]
            });

            function deleteProduct(id){
                Swal.fire({
                    title: "<?php echo e(__('trans.are_you_sure')); ?>",
                    text: "<?php echo e(__('trans.confirmation_warning')); ?>",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: '<?php echo e(__('trans.yes_delete')); ?>',
                    cancelButtonText: '<?php echo e(__('trans.cancel')); ?>'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            type: "POST",
                            url: "<?php echo e(route('product.destroy','id')); ?>".replace('id',id),
                            data: {
                                _token: "<?php echo e(csrf_token()); ?>",
                                _method: "DELETE",
                                id: id
                            },beforeSend: function(){
                                Swal.fire({
                                    title: '<?php echo e(__('trans.wait')); ?>',
                                    allowOutsideClick: false,
                                    didOpen: () => {
                                        Swal.showLoading()
                                        const content = Swal.getContent()
                                        if (content) {
                                            const b = content.querySelector('b')
                                            if (b) {
                                                b.textContent = Swal.getTimerLeft()
                                            }
                                        }
                                    },
                                })
                            },success: function (res) {
                                console.log(res);
                                if(res == 'true' || res == true || res == 1){
                                    Swal.fire(
                                        "Deleted!",
                                        "<?php echo e(__('trans.product_deleted')); ?>",
                                        "success"
                                    );
                                    table.row($("#row_"+id).parent().parent()).remove().draw();
                                }else{
                                    Swal.fire(
                                        "Deleted!",
                                        "<?php echo e(__('trans.product_delete_error')); ?>",
                                        "error"
                                    )
                                }
                            },error: function (e, textStatus, errorThrown) {
                                Swal.fire(
                                    "Error",
                                    errorThrown,
                                    "error"
                                )
                            }
                        });
                    }
                })
            }

        </script>
     <?php $__env->endSlot(); ?>

 <?php if (isset($__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d)): ?>
<?php $component = $__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d; ?>
<?php unset($__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH D:\XAMPP\htdocs\salagoposupgraded\resources\views/products-listing.blade.php ENDPATH**/ ?>