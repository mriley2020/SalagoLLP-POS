<header id="page-topbar">
    <div class="navbar-header">
        <div class="d-flex">
            <!-- LOGO -->
            <div class="navbar-brand-box">
                <a href="#" class="logo logo-light">
            <span class="logo-sm">
            <img src="<?php echo e(asset('assets/images/logo-small.png')); ?>" alt="" height="20">
            </span>
                    <span class="logo-lg">
            <img src="<?php echo e(asset('assets/images/logo-trans.png')); ?>" alt="" height="40">
            </span>
                </a>
            </div>
            <button type="button" class="btn btn-sm px-3 font-size-16 header-item waves-effect" id="vertical-menu-btn">
                <i class="fa fa-fw fa-bars"></i>
            </button>
        </div>
        <div class="d-flex">
            <div class="dropdown d-none d-lg-inline-block ml-1">
                <button type="button" class="btn header-item noti-icon waves-effect" data-toggle="fullscreen">
                    <i class="bx bx-fullscreen"></i>
                </button>
            </div>
            <div class="dropdown d-inline-block">
                <button type="button" class="btn header-item waves-effect" id="page-header-user-dropdown"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <img class="rounded-circle header-profile-user" img src="<?php echo e(asset('assets/images/users/avatar-1.jpg')); ?>"
                         alt="Header Avatar">
                    <span class="d-none d-xl-inline-block ml-1"><?php echo e(auth()->user()->name); ?></span>
                    <i class="mdi mdi-chevron-down d-none d-xl-inline-block"></i>
                </button>
                <div class="dropdown-menu dropdown-menu-right">
                    <!-- item-->
                    <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>"> <?php echo csrf_field(); ?>
                        <button class="dropdown-item text-danger">
                            <i class="bx bx-power-off font-size-16 align-middle mr-1 text-danger"></i> <?php echo e(__('auth.logout')); ?>

                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</header>

<?php /**PATH C:\xampp\htdocs\salago-upgraded\resources\views/includes/header.blade.php ENDPATH**/ ?>