<?php

use App\Http\Controllers\OrderController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ProductController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// by default this route will open login page actually this route will redirect the user ti login page
Route::redirect('/', 'login');

// Route::get('clear',function(){
//     Artisan::call('config:cache');
//     Artisan::call('migrate:refresh');
//     Artisan::call('storage:link');
// });



Auth::routes([
    'register'=> false,
    'reset' => false
]);

Route::group(['middleware'=>'auth'],function () {
    // dashboard route
    Route::get('dashboard', [HomeController::class, 'index'])->name('dashboard');
    // displaying category list in from ajax request in datatable
    Route::post('categories/get',[CategoryController::class,'getCategories'])->name('category.get');
    // all the method like create update delete are in this route
    // in expect parameter we put 2 values create and edit so dont need these 2 method or function
    Route::resource('categories', CategoryController::class)
        ->except('create','edit')
        ->names('category');

});
